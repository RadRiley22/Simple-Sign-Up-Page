from flask import *
app = Flask('simple web up')
# ----------routes----------
@app.route("/")
def home():
    return render_template('login.html')

@app.route("/login", methods=["POST"])
def login():
    pin = request.form["pin"]
    if pin == "1234":
        return "access granted"
    else:
        return "access denied"

# ----------run app----------
app.run(host="127.0.0.1", port=5000, debug=True)